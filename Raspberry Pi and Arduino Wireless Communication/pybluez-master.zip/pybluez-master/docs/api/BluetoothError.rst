BluetoothError
--------------

.. currentmodule:: bluetooth

.. autoexception:: BluetoothError
  :show-inheritance:
