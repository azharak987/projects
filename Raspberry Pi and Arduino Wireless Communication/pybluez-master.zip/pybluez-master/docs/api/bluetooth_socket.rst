BluetoothSocket
---------------

.. todo:: Add documentation for the BluetoothSocket methods.

.. currentmodule:: bluetooth

.. autoclass:: BluetoothSocket
  :show-inheritance:
  :members:
  :undoc-members: